// experiment no:1 for checking the turnaround time and average of FCFS algoritm.Devloped and compiled by Nirmal Ram . copyrighted 2018

#include<stdio.h>
int main()
{
int limit,arrive[20],burst[20],i,completetime[100],turnaround[100],waiting[100],avg[100];
printf("\n\nChecking Turnaround Time and Average : Developed & compiled by Nirmal Ram\n========================================================================\n\n");
printf("Enter the number of process : ");
scanf("%d",&limit);
printf("\nEnter the Arrival time and Burst time of processes :\n=================================================\n ");
for(i=1;i<=limit;i++)                   // set your values
{
printf("\nArrival Time of process %d :" , i);
scanf("%d",&arrive[i]);
printf("\nburst time of process %d : ",i);
scanf("%d",&burst[i]);
}
printf("\n\n Arrival Time and Burst Time addded succesfully ! \n=======================================================\n\n");
for(i=1 ; i<=limit;i++)
{
printf("Process %d :  Arival time : %d   Burst Time : %d \n\n",i,arrive[i],burst[i]);  // display inputs
}
printf("/n Calculating.........Completion Time , Turn Around Time and Waiting Time\n\n");
printf(" --------------------------------------------------------------------------------------------------------------\n");
completetime[1]=burst[1];
for (i=1;i<=limit;i++)
{
completetime[i+1]=completetime[i]+burst[i+1];
turnaround[i]=completetime[i]-arrive[i];
waiting[i]=turnaround[i]-burst[i];
printf("process %d | Arrival Time : %d | Burst Time : %d | Completion Time : %d | Turnaround Time : %d | Waiting time : %d |\n\n",i,arrive[i],burst[i],completetime[i],turnaround[i],waiting[i]);
}
printf("\n\nAverage Waiting Time calculating.........................\n\n");
avg[0]=0;
for (i=1;i<=limit;i++)
{
avg[i]=waiting[i]+avg[i-1];
}
printf("\n\n Average Time is Calculated : %d ",avg[limit]/limit);
printf("\n\n Programm is succesfully completed !! congratulation !\n=======================================================\n\nDeveloped and compiled : Nirmal Ram\ncompany:pineapplem3 Inc\n\n\n");

}
