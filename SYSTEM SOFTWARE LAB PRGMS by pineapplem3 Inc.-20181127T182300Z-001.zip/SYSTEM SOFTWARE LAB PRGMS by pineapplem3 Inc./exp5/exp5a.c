#include<stdio.h>
#include<stdlib.h>
int mutex=1;
int full=0;
int empty=5;
int n,value=0;
int main()
{
void producer();
void consumer();
int wait(int);
int signal(int);
while(1)
{
printf("\n\n==================================================================\n\n");
printf("\nEnter the Operation to be done");
printf("\n1 : produce item\n2 : consume item\n3: terminate");
printf("\n\nEnter the number of your choice : ");
scanf("%d",&n);
switch(n)
{
case 1 : {
if((empty!=0)&&(mutex==1))
{
produce();
}
else
{
printf("Sorry ! The buffer is full . please unload the payload");
}
break;
}
case 2 : {
if((full!=0)&&(mutex=1))
{
consume();
}
else
{
printf("Sorry ! There nothing in the Buffer . please fill the payload. contact producer");
}
break;
}
case 3 : {
return 0;
break;
}
default : {
printf("\nWarning : Please enter valid input\n");
}
}
}
return 0;
}

int signal(int s)
{
return(++s);
}
int wait(int w)
{
return(--w);
}
void produce()
{
mutex=wait(mutex);
full=signal(full);
empty=wait(empty);
value++;
printf("Producer loaded one payload into buffer ! ");
mutex=signal(mutex);
}
void consume()
{
mutex=wait(mutex);
full=wait(full);
empty=signal(empty);
value--;
printf("Consumer unloaded one payload from buffer !");
mutex=signal(mutex);
}








