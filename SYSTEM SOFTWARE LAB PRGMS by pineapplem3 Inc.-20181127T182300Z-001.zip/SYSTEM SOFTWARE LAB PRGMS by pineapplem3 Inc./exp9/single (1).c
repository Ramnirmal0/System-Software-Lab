#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct dir
{
	char filname[30];
	struct dir *link;
}*new=NULL,*ptr=NULL,*head=NULL,*preptr=NULL;
int check(char *);
char name[30];
int flag,f;
char dname[20];
void main()
{
	printf("enter the directory name \n");
	scanf("%s",dname);
	int c,ch;
	for(;;)
	{	

		printf("Enter your choice 1 to Create 2 to Delete 3 to Search 4 to display 5 to exit \n");
		scanf("%d",&c);
		switch(c)
		{
			case 1:	
				new=(struct dir*)malloc(sizeof(struct dir)); 
				printf("Enter the file name:\n");
				scanf("%s",name);
				flag=check(name);
				if(flag==1)
				{
					if(head==NULL)                                                  
					{
						head=new;
						strcpy(new->filname,name);
						new->link=NULL;
					}
					else
					{
						strcpy(new->filname,name);
						new->link=head;
						head=new;
					}
				}
				else
				{
					printf("File is already existing \n");
				}
				break;
				
			case 2:
				flag=0;
				ptr=head;
				preptr=NULL;
				if(ptr==NULL)
				printf("No files are there in the directory\n");
				else
				{
					printf("Enter the file name:\n");
					scanf("%s",name);
					do
					{
						f=strcmp(ptr->filname,name);
						if(f==0)
						{
							if((ptr->link==NULL)&&(preptr==NULL))
							{
								head=NULL;
								free(ptr);
								flag=1;
								break;
							}
							else if((ptr->link!=NULL)&&(preptr==NULL))
							{
								head=ptr->link;
									flag=1;
									free(ptr);
									break;
							}
							else
							{
								preptr->link=ptr->link;
								ptr=NULL;
								free(ptr);
								flag=1;
								break;
							}
						}
					preptr=ptr;
					ptr=ptr->link;
					}while(ptr!=NULL);
					if(flag==0)
					printf("File does not exist\n");
				}
				break;
				
			case 3:
				flag=0;
				ptr=head;
				if(ptr==NULL)
					printf("No files are existing in the directory\n");
				else
				{
					printf("Enter the file name:\n");
					scanf("%s",name);
					do
					{
						f=strcmp(ptr->filname,name);
						if(f==0)
						{
							printf("File found\n");
							flag=1;
							break;
						}
						ptr=ptr->link;
					}while(ptr!=NULL);
					if(flag==0)
						printf("File not found\n");
				}
				break;	
				
			case 4:
				ptr=head;
				if(ptr==NULL)
					printf("No files existing in the directory\n");
				else
				{
					printf("The files in the directory are \n");
					while(ptr!=NULL)
					{
						printf("\t%s\n",ptr->filname);
						ptr=ptr->link;
					}
				}
				break;
				
			case 5:
				exit(0);
				break;
				
			default:
				printf("Invalid Option\n");
		}
	}
}
int check(char n[30])
{
	ptr=head;
	if(ptr==NULL)
		return 1;
	do
	{
		printf("%s",dname);
		f=strcmp(ptr->filname,n);
		if(f==0)
			return 0;
		ptr=ptr->link;
	}while(ptr!=NULL);
	return 1;
}
