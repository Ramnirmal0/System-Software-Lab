#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct dir
{
	char dirname[30];
	struct fil *files;
	struct dir *link;
}*new=NULL,*ptr=NULL,*head=NULL,*preptr=NULL;

struct fil
{
	char filname[30];
	struct fil *next;
}*fnew=NULL,*fptr=NULL,*fpreptr=NULL;

void create_directory();
void create_file();
void display_root();
void delete_dir();
void delete_file();
void search();

char name[30];
int flag,f;

void main()
{
	int c;
	for(;;)
	{
		
		printf(" Enter your choice\n");
		printf("1 to Create directory \n 2 to Create file in the directory \n 3 to Delete directory \n 4 to Delete files in the directory \n 5 to Search a file \n 6 to display root directory \n 7 to exit \n");
		scanf("%d",&c);
		switch(c)
		{
			case 1:
				create_directory();
				break;
				
			case 2:
				create_file();
				break;
				
			case 3:
				delete_dir();
				break;
				
			case 4:
				delete_file();
				break;
				
			case 5:
				search();
				break;	
				
			case 6:
				display_root();
				break;
				
			case 7:
				exit(0);
				break;
				
			default:
				printf("Invalid Option\n");
		}
	}
}

void create_directory()
{
	printf("Enter the name of the directory:\n");
	scanf("%s",name);
	flag=check(name);
	if(flag==1)
	{
		struct dir *new=(struct dir*)malloc(sizeof(struct dir)); 
		if(head==NULL)                                                  
		{
			strcpy(new->dirname,name);
			new->files=NULL;
			new->link=NULL;
			head=new;
		}
		else
		{
			strcpy(new->dirname,name);
			new->files=NULL;
			new->link=head;
			head=new;
		}
		printf("Directory is created\n");
	}
	else
	{
		printf("Directory is already existing\n");
	}
	
}

int check(char n[30])
{
	ptr=head;
	if(ptr==NULL)
		return 1;
	do
	{
		f=strcmp(ptr->dirname,n);
		if(f==0)
			return 0;
		ptr=ptr->link;
	}while(ptr!=NULL);
	return 1;
}

void create_file()
{
	fpreptr=NULL;
	printf("Enter the name of the directory in which file is to created:\n");
	scanf("%s",name);
	flag=check(name);
	if(flag==0)
	{
		printf("Enter the file name:\n");
		scanf("%s",name);
		if(ptr->files!=NULL)
		{
			fptr=ptr->files;
			do
			{
				f=strcmp(fptr->filname,name);
				if(f==0)
				{
					flag=1;
					break;
				}
				fpreptr=fptr;
				fptr=fptr->next;
			}while(fptr!=NULL);
			if(flag==1)
			{
				printf("File already exist in the directory\n");
			}
			else
			{
				struct fil *fnew=(struct fil*)malloc(sizeof(struct fil));
				strcpy(fnew->filname,name);
				fnew->next=NULL;
				fpreptr->next=fnew;
				printf("File is created\n");
			}
		}
		else
		{
			struct fil *fnew=(struct fil*)malloc(sizeof(struct fil));
			strcpy(fnew->filname,name);
			fnew->next=NULL;
			ptr->files=fnew;
			printf("File is created\n");	
		}
	}
	else
		printf("Directory does not exist\n");
}

void display_root()
{
	if(head==NULL)
	{
		printf("Root is empty\n");
	}
	else
	{
		printf("Root is\n");
		ptr=head;
		do
		{
			printf("\t%s:\n",ptr->dirname);
			if(ptr->files!=NULL)
			{
				fptr=ptr->files;
				do
				{
					printf("\t\t%s\n",fptr->filname);
					fptr=fptr->next;
				}while(fptr!=NULL);
			}
			else
			{
				printf("This directory is empty\n");
			}
			ptr=ptr->link;
		}while(ptr!=NULL);
	}
}

void delete_dir()
{
	flag=0;
	ptr=head;
	preptr=NULL;
	if(ptr==NULL)
		printf("Root is empty\n");
	else
	{
		printf("Enter the diectory name:\n");
		scanf("%s",name);
		do
		{
			f=strcmp(ptr->dirname,name);
			if(f==0)
			{
				if((ptr->link==NULL)&&(preptr==NULL))
				{
					head=NULL;
					free(ptr);
					flag=1;
					break;
				}
				else if((ptr->link!=NULL)&&(preptr==NULL))
				{
					head=ptr->link;
					flag=1;
					free(ptr);
					break;
				}
				else
				{
					preptr->link=ptr->link;
					ptr=NULL;
					free(ptr);
					flag=1;
					break;
				}
			}
			preptr=ptr;
			ptr=ptr->link;
		}while(ptr!=NULL);
		if(flag==0)
			printf("Directory is not found!\n");
		else
			printf("Directory is deleted\n");
	}
}

void delete_file()
{
	fpreptr=NULL;
	printf("Enter the directory name:\n");
	scanf("%s",name);
	flag=check(name);
	if(flag==0)
	{
		printf("Enter the file name:\n");
		scanf("%s",name);
		if(ptr->files==NULL)
		{
			printf("This directory is empty\n");
		}
		else
		{
			fptr=ptr->files;
			do
			{
				f=strcmp(fptr->filname,name);
				if(f==0)
				{
					if((fptr->next==NULL)&&(fpreptr==NULL))
					{
						ptr->files=NULL;
						free(fptr);
						flag=1;
						break;
					}
					else if((fptr->next!=NULL)&&(fpreptr==NULL))
					{
						ptr->files=fptr->next;
						flag=1;
						free(fptr);
						break;
					}
					else
					{
						fpreptr->next=fptr->next;
						fptr=NULL;
						free(fptr);
						flag=1;
						break;
					}
				}
				fpreptr=fptr;
				fptr=fptr->next;
			}while(fptr!=NULL);
			if(flag==0)
				printf("File is not found\n");
			else
				printf("File is deleted\n");
			
		}
	}
	else
		printf("Directory does not exist\n");
}

void search()
{
	printf("Enter the file name to be search:");
	scanf("%s",name);
	flag=0;
	ptr=head;
	if(ptr==NULL)
		printf("Root is empty\n");
	else
	{
		do
		{
			f=strcmp(ptr->dirname,name);
			if(f==0)
			{
				flag=1;
				printf("Directory with the name %s found\n",name);
				break;
			}
			ptr=ptr->link;
		}while(ptr!=NULL);
		ptr=head;
		do
		{
			fptr=ptr->files;
			while(fptr!=NULL)
			{
				f=strcmp(fptr->filname,name);
				if(f==0)
				{
					flag=1;
					printf("File with the name '%s' found inside directory %s \n",name,ptr->dirname);
					break;
				}
				fptr=fptr->next;
			}
			ptr=ptr->link;
		}while(ptr!=NULL);
		if(flag==0)
		{
			printf("No files or directories found with the name %s \n",name);
		}
	}
}
